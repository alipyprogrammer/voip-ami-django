from rest_framework import generics
from .models import ActiveChannels
from .serializers import *
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .models import *
import colorama
from django.views import View
from colorama import Fore
from django.shortcuts import render
from django.db.models import Q
from datetime import datetime

@api_view(['POST'])
def ActiveChannelsViews(request):
    
    data = request.data
    ChannelsItem = data['data']
    channel_layer = get_channel_layer()

  

    print(Fore.GREEN + "======= active channels =========")
    
    ActiveChannels.objects.all().delete()   
    
    print(Fore.GREEN + "deleted")
    
    items_to_create = [ActiveChannels(channel=i['channel']) for i in ChannelsItem]
    ActiveChannels.objects.bulk_create(items_to_create)
    

    ActiveChannels_data = [{'channel': i['channel']} for i in ChannelsItem]
    async_to_sync(channel_layer.group_send)(
    "member_channels",
        {
            "type": "data_ActiveChannels_channels",
            "data": ActiveChannels_data,
        },
    )
    


    print(Fore.GREEN + "done")
    print(Fore.GREEN + "======= End =========")



    return Response('ok')






# @api_view(['POST'])
# def PeersViews(request):
    
#     data = request.data
#     AddItem = data['data']

#     channel_layer = get_channel_layer()
 
#     print(Fore.BLUE + "============ Peers ==============")


#     data_match = True
    
#     for item in AddItem:
#         name = item['name']
#         status = item['status'][:2] 
        
#         if Peers.objects.filter(name=name).exists():
#             existing_status = Peers.objects.get(name=name).status[:2]
#             if existing_status != status:
#                 data_match = False
#                 break  
            



#     if data_match:
#         items_to_create = [Peers(name=i['name'] , status =i['status'] ) for i in AddItem]
#         Peers.objects.bulk_create(items_to_create)


#         Peers_data = [{'name': i['name'], 'status': i['status']} for i in AddItem]
#         async_to_sync(channel_layer.group_send)(
#         "Peers_channels",
#             {
#                 "type": "data_peers",
#                 "data": Peers_data,
#             },
#         )

#         print(Fore.BLUE + "done")
#         print(Fore.BLUE + "======= End =========")


#     return Response('ok')


@api_view(['POST'])
def PeersViews(request):
    
    data = request.data
    AddItem = data['data']

    channel_layer = get_channel_layer()
 
    print(Fore.BLUE + "============ Peers ==============")
    
    AddItem = data['data']  

    items_to_create = []    
    exitItem = False
    for i in AddItem:
        existing_item = Peers.objects.filter(name=i['name'])
        if not existing_item.exists():
            exitItem = True
            print(i)
            break

    if exitItem :
        Peers.objects.all().delete()   
        print(Fore.BLUE + "deleted")


        nowTime = datetime.now()
        now = nowTime.strftime("%H:%M:%S")
        
        items_to_create = [Peers(name=i['name'] , status =i['status'] ,dateUpdate =now) for i in AddItem]
        Peers.objects.bulk_create(items_to_create)

        PeersData = [{'name': i['name'] ,'status': i['status'] , 'dateUpdate': now} for i in AddItem]
        async_to_sync(channel_layer.group_send)(
        "Peers_channels",
            {
                "type": "data_peers",
                "data": PeersData,
            },
        )

    
    
    print(Fore.BLUE + "done")
    print(Fore.BLUE + "======= End =========")


    return Response('ok')


   



   





    


@api_view(['POST'])
def QueueViews(request):

    data = request.data

    MemberData = data['Members']
    exitMemberData = False

    CallersData = data['Callers']
    exitCallerData = False

    channel_layer = get_channel_layer()

    nowTime = datetime.now()
    now = nowTime.strftime("%H:%M:%S")

  
    print(Fore.BLUE + "============ Queue ==============")



    if len(CallersData) ==0 :
        caller_data = [{'name': i['code'], 'wait': i['wait'] , 'dateUpdate' : now} for i in CallersData]
        Callers.objects.all().delete()   
        async_to_sync(channel_layer.group_send)(
        "caller_channels",
            {
                "type": "data_caller_channels",
                "data": caller_data,
            },
        )
        print(Fore.YELLOW + "no caller")
        


    #Member
    for m in MemberData :
        exist_member_item = Member.objects.filter(number=m['code'] , status =m['status'] )
        if not exist_member_item.exists():
            exitMemberData = True
            print(f"member  : {m}")
            break

    if  exitMemberData:
        Member.objects.all().delete()   

        print("member deleted")

        member_items_to_create = [Member(number=i['code'] , status=i['status'] ) for i in MemberData]
        Member.objects.bulk_create(member_items_to_create)
        member_data = [{'number': i['code'], 'status': i['status']} for i in MemberData]
        async_to_sync(channel_layer.group_send)(
        "member_channels",
            {
                "type": "data_member_channels",
                "data": member_data,
            },
        )
        print("member_exist_done")





    #Caller

    for c in CallersData :
        exit_Callers_item = Callers.objects.filter(name=c['code'])
        if not exit_Callers_item.exists():
            exitCallerData = True
            print(f"caller : {c}")
            break

    if exitCallerData:
        Callers.objects.all().delete()  
        
        print("caller deleted")

        Caller_items_to_create = [Callers(name=i['code'] , wait=i['wait'] , dateUpdate =now) for i in CallersData]
        Callers.objects.bulk_create(Caller_items_to_create)
        
        caller_data = [{'name': i['code'], 'wait': i['wait'] , 'dateUpdate' : now} for i in CallersData]
        async_to_sync(channel_layer.group_send)(
        "caller_channels",
            {
                "type": "data_caller_channels",
                "data": caller_data,
            },
        )
        print("caller_exist_done")

    print(Fore.BLUE + "======= End =========")

    return Response('ok')


class Index(View):
    def get(self , request):
        context ={
            'test' : 'Hello word'
        }
        return render(request , 'test.html')

