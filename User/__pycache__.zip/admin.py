from django.contrib import admin
from django.contrib.auth.admin import UserAdmin


from .models import *
# Register your models here.


UserAdmin.fieldsets[2][1]['fields'] =(
    'Code',
    'is_active',
    'is_staff',
    'is_superuser',
    'groups',
    'name',
    'phoneNumber',
    'codeMeli',
    'image',
    'address',
    'IsCustomer',
    'IsSalesExpert',
    'ISMweb',
    'IsMads',
    'IsMCoordination',
    'IsStorageUnit',
    'IsDriver',
    'IsSeller',
    'IsSerial',
    'IsMali',
    'IsManager',
    'workPosition',

    # greenAir

    'GreenAirIsMads',
    'GreenAirIsSalesExpert',
)
# UserAdmin.list_display += ('is_author','is_special_user')
admin.site.register(User, UserAdmin)
admin.site.register(Age)