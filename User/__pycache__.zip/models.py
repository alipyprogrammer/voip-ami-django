from pyexpat import model
from statistics import mode
from django.db import models
from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils import timezone
import os



def upload_image_path(instance, filename):
    name, ext = get_filename_ext(filename)
    final_name = f"{instance.id}-{instance.name}{ext}"
    return f"user/{final_name}"


class Age(models.Model):
    Age = models.CharField(max_length=50 , verbose_name='سن')





class User(AbstractUser):
    STATUS_CHOICES =( 
    ('mo',"مشتری"),
    ('an',"انبار دار"),
    ('st',"فروشنده (استایلوس)"),
    ('ca',"کارشناس فروش "),
    ('we',"مدیر وب سایت"),
    ('mo',"مدیر"),
    ('ta',"مدیر تبلیغات     "),

                     )
    Age_CHOICES = (
       ('bl' , ""),
       ('zb' , " زیر 25 سال"),
       ('bc' , "۲۵ تا ۳۵ سال"),
       ('cc' , "۳۵ تا ۴۵ سال"),
       ('ch' , "۴۵ سال به بالا"),
    )
    name            = models.CharField(max_length=40 ,null=True , blank=True)
    phoneNumber     = models.CharField(max_length=11 ,null=True , blank=True,verbose_name='شماره تلفن')
    codeMeli        = models.CharField(max_length=10 , verbose_name='کد ملی',null=True , blank=True)
    image           = models.ImageField(upload_to =upload_image_path ,null=True , blank=True )
    address         = models.TextField(max_length=200, verbose_name='آدرس' ,null=True , blank=True)
    Age             = models.CharField(max_length=50 , null=True , blank=True, verbose_name='سن')
    IsCustomer      = models.BooleanField(default=False ,verbose_name='مشتری')
    IsSalesExpert   = models.BooleanField(default=False, verbose_name='کارشناس فروش ')
    ISMweb          = models.BooleanField(default=False, verbose_name='مدیر وب سایت  ')
    IsMads          = models.BooleanField(default=False, verbose_name='مدیر تبلیغات')
    IsMCoordination = models.BooleanField(default=False, verbose_name='مدیر واحد هماهنگی')
    IsStorageUnit   = models.BooleanField(default=False, verbose_name='واحد انبار داری ')
    IsDriver        = models.BooleanField(default=False , verbose_name='راننده')
    IsSeller        = models.BooleanField(default=False , verbose_name='فروشنده')
    IsSerial        = models.BooleanField(default=False , verbose_name='دسترسی به صحفه سریال')
    IsMali          = models.BooleanField(default=False , verbose_name=' مالی  ')
    IsManager       = models.BooleanField(default=False , verbose_name=' مدریت  ')
    Code            = models.CharField(max_length = 150 , null=True , blank=True)
    workPosition    = models.CharField(max_length=150 , null=True , blank=True, verbose_name='جایگاه شغلی')  


    #GreenAir 
    GreenAirIsMads  = models.BooleanField(default=False , verbose_name='(greenAir)مدریت تبلیغات')
    GreenAirIsSalesExpert  = models.BooleanField(default=False , verbose_name='(greenAir) کارشناس فروش ')


  
