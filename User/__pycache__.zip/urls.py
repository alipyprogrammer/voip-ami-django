from django.urls import path 
from .views import *
from . import views
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
)


urlpatterns = [
    path('login', views.MyTokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('profile/', views.getUserProfile,name="UserProfile"),
    path('DriverAndSeller/' , DriverAndSellerList.as_view() , name='DriverAndSellerList'),
    path('list/' , UserList.as_view() , name='UserList'),
    path('update/<str:pk>/' ,UserUpdate.as_view() ,name="UserUpdate"),
    path('delete/<str:pk>/' ,UserDelete.as_view() ,name="UserUpdate"),
    path('add/' ,views.UserAdd ,name="UserAdd"),




]

