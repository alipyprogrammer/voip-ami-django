from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from rest_framework_simplejwt.views import TokenObtainPairView
from .serializers import *
from rest_framework.permissions import IsAuthenticated ,IsAdminUser
from rest_framework.decorators import  api_view,permission_classes
from rest_framework.response import Response
from rest_framework.generics import ListAPIView ,RetrieveUpdateAPIView,CreateAPIView,DestroyAPIView
from django.contrib.auth.hashers import make_password
from rest_framework import status
from User import get_user_model

class MyTokenObtainPairSerializer(TokenObtainPairSerializer):
    def validate(self,attrs):
        data = super().validate(attrs)



        serializers = UserSerializerWithToken(self.user).data
        for k , v in serializers.items():
            data[k]= v
        return data
    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)

        # Add custom claims
        token['username'] = user.username
        token['message'] = 'سلام به سایت یقه خوش آمدید'
    
            # ...

        return token

class MyTokenObtainPairView(TokenObtainPairView):
    serializer_class = MyTokenObtainPairSerializer




@api_view(['GET'])
@permission_classes([IsAuthenticated])
def getUserProfile(request):
    user = request.user 
    serializer = UserSerializer(user , many=False)
    return Response(serializer.data)



class DriverAndSellerList(ListAPIView):
    queryset = User.objects.all()
    serializer_class= UserSerializer
    filterset_fields = ('IsDriver','IsSeller')


class UserList(ListAPIView):
    queryset = User.objects.all()
    serializer_class= UserSerializer
    filterset_fields = ('IsSalesExpert',)



# class UserAdd(CreateAPIView):
#     queryset =User.objects.all()
#     serializer_class =UserSerializer


@api_view(['PUT'])
@permission_classes([IsAuthenticated])
def UpdatePasswordUser(request): 
    user = request.user 
    serializer = UserSerializerWithToken(user , many=False)
    data = request.data 
    user.username   =  data['username']
    user.phoneNumber      =  data['phoneNumber']
    if data['password'] != '':
        user.password = make_password(data['password'])
    user.save()
    return Response(serializer.data)



@api_view(['POST'])
def UserAdd(request):
    data =request.data 
    try :
        users =get_user_model()
        user = users.objects.create( 
            first_name =data['first_name'],
            username   =data['username'],
            phoneNumber=data['phoneNumber'],
            password   =make_password(data['password']),
            codeMeli = data['codeMeli'],
            Age = data['Age'],
            # address = data['address'],
            Code = data['Code'],
            workPosition = data['workPosition'],
            IsCustomer = data['IsCustomer'],
            IsSalesExpert = data('IsSalesExpert'),
            ISMweb = data['ISMweb'],
            IsMads = data['IsMads'],
            IsMCoordination = data['IsMCoordination'],
            IsStorageUnit = data['IsStorageUnit'],
            IsDriver = data['IsDriver'],
            IsSeller = data['IsSeller'],
            IsSerial = data['IsSerial'],
            IsMali = data['IsMali'],
            IsManager = data['IsManager'],

        )
        serializer = UserSerializerWithToken(user,many=False)
        return Response(serializer.data)
    except:
        message = {'detail':'خطا '}
        return Response(message, status=status.HTTP_400_BAD_REQUEST)


class UserUpdate(RetrieveUpdateAPIView):
    queryset =User.objects.all()
    serializer_class =UserSerializer


class UserDelete(DestroyAPIView):
    queryset =User.objects.all()
    serializer_class =UserSerializer



